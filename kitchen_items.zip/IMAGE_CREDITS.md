# Mutfak destesinin 50 görseli

Görseller Wikimedia Commons dosya sayfalarında belirtilen açık lisanslarla dağıtılır. Her görselin yazarı, kaynak sayfası ve lisansı aşağıdadır. Dosyalar sanatsal olarak değiştirilmemiştir; bazıları Wikimedia'nın sağladığı küçültülmüş sürümdür. Kaynak sayfasındaki ek atıf bilgileri de korunmalıdır. Lisanslar tüm uygulamaya tek bir lisans atamak için birleştirilmemiştir; her görselin kendi kaydı vardır.

Bu sette fotoğrafların yanında çizim veya üç boyutlu görselleştirmeler de bulunabilir. Bir görseldeki model veya marka, örnek cümledeki eşyayla birebir aynı olmak zorunda değildir. Fotoğraf içindeki üretici adları uygulamanın markası değildir.

Uygulamanın Kaynaklar/Hakkında ekranında bu dosyaya veya her görselin kaydına ulaşılabilmelidir. `imageAttribution` alanı mevcut Android modelinde kendiliğinden ekrana çıkmaz.

Önerilen giriş: “Kitchen images sourced from Wikimedia Commons. Individual authors, sources and licenses are listed in Kitchen Image Credits.” Bu genel cümleye ek olarak aşağıdaki tekil yazar ve lisans kayıtlarını erişilebilir tutun.

## spoon

- Dosya: `images/spoon.jpg`
- Eser: SpoonOnTable.jpg
- Yazar: Denmarkball lego
- Kaynak: https://commons.wikimedia.org/wiki/File:SpoonOnTable.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## fork

- Dosya: `images/fork.jpg`
- Eser: Fork.agr.jpg
- Yazar: ArnoldReinhold
- Kaynak: https://commons.wikimedia.org/wiki/File:Fork.agr.jpg
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## knife

- Dosya: `images/knife.jpg`
- Eser: Kitchen knife by yashima.jpg
- Yazar: yashima from Japan
- Kaynak: https://commons.wikimedia.org/wiki/File:Kitchen_knife_by_yashima.jpg
- Lisans: [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## teaspoon

- Dosya: `images/teaspoon.jpg`
- Eser: Teaspoon.jpg
- Yazar: S Sepp
- Kaynak: https://commons.wikimedia.org/wiki/File:Teaspoon.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## tablespoon

- Dosya: `images/tablespoon.jpg`
- Eser: Eetlepel.jpg
- Yazar: Koetje123456789
- Kaynak: https://commons.wikimedia.org/wiki/File:Eetlepel.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## plate

- Dosya: `images/plate.jpg`
- Eser: Plate Poland 02.jpg
- Yazar: Abraham
- Kaynak: https://commons.wikimedia.org/wiki/File:Plate_Poland_02.jpg
- Lisans: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## bowl

- Dosya: `images/bowl.jpg`
- Eser: Salisbury 'Greba' bowl - 2022-07-20 - Andy Mabbett - 01.jpg
- Yazar: Andy Mabbett
- Kaynak: https://commons.wikimedia.org/wiki/File:Salisbury_%27Greba%27_bowl_-_2022-07-20_-_Andy_Mabbett_-_01.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## cup

- Dosya: `images/cup.jpg`
- Eser: Filiżanka porcelanowa Weimar Porzellan.jpg
- Yazar: Przemek.Zborowski
- Kaynak: https://commons.wikimedia.org/wiki/File:Fili%C5%BCanka_porcelanowa_Weimar_Porzellan.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## mug

- Dosya: `images/mug.jpg`
- Eser: Mug.jpg
- Yazar: Filo gèn'
- Kaynak: https://commons.wikimedia.org/wiki/File:Mug.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## glass

- Dosya: `images/glass.jpg`
- Eser: Glass of water.jpg
- Yazar: deavmi
- Kaynak: https://commons.wikimedia.org/wiki/File:Glass_of_water.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## saucepan

- Dosya: `images/saucepan.jpg`
- Eser: Hahn 16cm Saucepan.jpg
- Yazar: Cooks & Kitchens from Darlington, UK
- Kaynak: https://commons.wikimedia.org/wiki/File:Hahn_16cm_Saucepan.jpg
- Lisans: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## frying pan

- Dosya: `images/frying_pan.jpg`
- Eser: Pfanne (Edelstahl).jpg
- Yazar: See source file page
- Kaynak: https://commons.wikimedia.org/wiki/File:Pfanne_(Edelstahl).jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## pot

- Dosya: `images/pot.png`
- Eser: Pot with no background.png
- Yazar: Lightsnap
- Kaynak: https://commons.wikimedia.org/wiki/File:Pot_with_no_background.png
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## lid

- Dosya: `images/lid.jpg`
- Eser: A lid for a pot.jpg
- Yazar: BogTar201213
- Kaynak: https://commons.wikimedia.org/wiki/File:A_lid_for_a_pot.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## chopping board

- Dosya: `images/chopping_board.jpg`
- Eser: Wooden Chopping Board.jpg
- Yazar: Pisethinfo
- Kaynak: https://commons.wikimedia.org/wiki/File:Wooden_Chopping_Board.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## spatula

- Dosya: `images/spatula.jpg`
- Eser: Spatulas.jpg
- Yazar: Kafziel (talk) at en.wikipedia
- Kaynak: https://commons.wikimedia.org/wiki/File:Spatulas.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## ladle

- Dosya: `images/ladle.jpg`
- Eser: Ladle steel 18j07.JPG
- Yazar: Snowmanradio
- Kaynak: https://commons.wikimedia.org/wiki/File:Ladle_steel_18j07.JPG
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## whisk

- Dosya: `images/whisk.jpg`
- Eser: Whisk (IMG 0265).jpg
- Yazar: Matti Blume
- Kaynak: https://commons.wikimedia.org/wiki/File:Whisk_(IMG_0265).jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## tongs

- Dosya: `images/tongs.png`
- Eser: Kitchen-tongs.png
- Yazar: Sac86738 at English Wikipedia
- Kaynak: https://commons.wikimedia.org/wiki/File:Kitchen-tongs.png
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## peeler

- Dosya: `images/peeler.jpg`
- Eser: Peeler 01 Pengo.jpg
- Yazar: Pengo
- Kaynak: https://commons.wikimedia.org/wiki/File:Peeler_01_Pengo.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## grater

- Dosya: `images/grater.jpg`
- Eser: Grater (tarka).jpg
- Yazar: MOs810
- Kaynak: https://commons.wikimedia.org/wiki/File:Grater_(tarka).jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## colander

- Dosya: `images/colander.jpg`
- Eser: Blue colander.jpg
- Yazar: FAP
- Kaynak: https://commons.wikimedia.org/wiki/File:Blue_colander.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## sieve

- Dosya: `images/sieve.jpg`
- Eser: Kitchen sieves.jpg
- Yazar: Vis M
- Kaynak: https://commons.wikimedia.org/wiki/File:Kitchen_sieves.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## rolling pin

- Dosya: `images/rolling_pin.jpg`
- Eser: Rollingpin.jpg
- Yazar: Peter Kammer
- Kaynak: https://commons.wikimedia.org/wiki/File:Rollingpin.jpg
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## baking tray

- Dosya: `images/baking_tray.jpg`
- Eser: Uncooked stuffed mushrooms on a baking tray, 2006.jpg
- Yazar: Rachel Ricci
- Kaynak: https://commons.wikimedia.org/wiki/File:Uncooked_stuffed_mushrooms_on_a_baking_tray,_2006.jpg
- Lisans: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## oven glove

- Dosya: `images/oven_glove.jpg`
- Eser: Baking glove.jpg
- Yazar: Lymantria
- Kaynak: https://commons.wikimedia.org/wiki/File:Baking_glove.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## apron

- Dosya: `images/apron.png`
- Eser: Apron with pockets for clothes pegs.png
- Yazar: Wribln
- Kaynak: https://commons.wikimedia.org/wiki/File:Apron_with_pockets_for_clothes_pegs.png
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## tea towel

- Dosya: `images/tea_towel.jpg`
- Eser: Viskestykke.jpg
- Yazar: Nillerdk
- Kaynak: https://commons.wikimedia.org/wiki/File:Viskestykke.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## dishcloth

- Dosya: `images/dishcloth.jpg`
- Eser: Dishcloths.jpg
- Yazar: anna saccheri from Palo Alto, United States
- Kaynak: https://commons.wikimedia.org/wiki/File:Dishcloths.jpg
- Lisans: [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## sponge

- Dosya: `images/sponge.jpg`
- Eser: Cleaning sponge.jpg
- Yazar: Jiafei Slay Queen
- Kaynak: https://commons.wikimedia.org/wiki/File:Cleaning_sponge.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## washing-up liquid

- Dosya: `images/washing_up_liquid.jpg`
- Eser: Dish-soap.jpg
- Yazar: user:Eladkrauz
- Kaynak: https://commons.wikimedia.org/wiki/File:Dish-soap.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## sink

- Dosya: `images/sink.jpg`
- Eser: High End Kitchen Sink 2a.jpg
- Yazar: Stilfehler
- Kaynak: https://commons.wikimedia.org/wiki/File:High_End_Kitchen_Sink_2a.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## tap

- Dosya: `images/tap.jpg`
- Eser: Kitchen Faucet 1.jpg
- Yazar: Stilfehler
- Kaynak: https://commons.wikimedia.org/wiki/File:Kitchen_Faucet_1.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## bin

- Dosya: `images/bin.jpg`
- Eser: Kitchen compost bin - Sarah Stierch.jpg
- Yazar: Missvain
- Kaynak: https://commons.wikimedia.org/wiki/File:Kitchen_compost_bin_-_Sarah_Stierch.jpg
- Lisans: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## fridge

- Dosya: `images/fridge.jpg`
- Eser: US Domestic Refrigerator - Frigidaire.jpg
- Yazar: Infrogmation of New Orleans
- Kaynak: https://commons.wikimedia.org/wiki/File:US_Domestic_Refrigerator_-_Frigidaire.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## freezer

- Dosya: `images/freezer.jpg`
- Eser: Frysbox C90, TEKA0069218.jpg
- Yazar: AB Electrolux/ Tekniska Museet
- Kaynak: https://commons.wikimedia.org/wiki/File:Frysbox_C90,_TEKA0069218.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## oven

- Dosya: `images/oven.jpg`
- Eser: Panasonic ELECTRIC OVEN NB-H3800.jpg
- Yazar: Dinkun Chen
- Kaynak: https://commons.wikimedia.org/wiki/File:Panasonic_ELECTRIC_OVEN_NB-H3800.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## hob

- Dosya: `images/hob.jpg`
- Eser: Kookplaat inductie.JPG
- Yazar: Erik1980 at Dutch Wikipedia
- Kaynak: https://commons.wikimedia.org/wiki/File:Kookplaat_inductie.JPG
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## microwave

- Dosya: `images/microwave.jpg`
- Eser: Microwave Oven.jpg
- Yazar: Srini297
- Kaynak: https://commons.wikimedia.org/wiki/File:Microwave_Oven.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## kettle

- Dosya: `images/kettle.jpg`
- Eser: Electric kettle phillips white.JPG
- Yazar: Rafa
- Kaynak: https://commons.wikimedia.org/wiki/File:Electric_kettle_phillips_white.JPG
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## toaster

- Dosya: `images/toaster.png`
- Eser: Toaster.png
- Yazar: The user wants to remain anonymous.
- Kaynak: https://commons.wikimedia.org/wiki/File:Toaster.png
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## blender

- Dosya: `images/blender.jpg`
- Eser: Blender.jpg
- Yazar: Myself
- Kaynak: https://commons.wikimedia.org/wiki/File:Blender.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## mixer

- Dosya: `images/mixer.jpg`
- Eser: Миксер ДОМОТЕК.jpg
- Yazar: Schekinov Alexey Victorovich
- Kaynak: https://commons.wikimedia.org/wiki/File:%D0%9C%D0%B8%D0%BA%D1%81%D0%B5%D1%80_%D0%94%D0%9E%D0%9C%D0%9E%D0%A2%D0%95%D0%9A.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## dishwasher

- Dosya: `images/dishwasher.jpg`
- Eser: KitchenAid home dishwasher - Open.jpg
- Yazar: Infrogmation
- Kaynak: https://commons.wikimedia.org/wiki/File:KitchenAid_home_dishwasher_-_Open.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## coffee maker

- Dosya: `images/coffee_maker.jpg`
- Eser: Electric Brew Coffee Maker.jpg
- Yazar: GautamSudhanshu
- Kaynak: https://commons.wikimedia.org/wiki/File:Electric_Brew_Coffee_Maker.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## teapot

- Dosya: `images/teapot.jpg`
- Eser: Teapot 2010 G1.jpg
- Yazar: George Chernilevsky
- Kaynak: https://commons.wikimedia.org/wiki/File:Teapot_2010_G1.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## bottle

- Dosya: `images/bottle.jpg`
- Eser: Glass Water Bottle.JPG
- Yazar: Amraepowell
- Kaynak: https://commons.wikimedia.org/wiki/File:Glass_Water_Bottle.JPG
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## jar

- Dosya: `images/jar.png`
- Eser: A Glass Jar with Threaded Rim On a Clear Transparent Background.png
- Yazar: Muldoonsamuel55
- Kaynak: https://commons.wikimedia.org/wiki/File:A_Glass_Jar_with_Threaded_Rim_On_a_Clear_Transparent_Background.png
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## container

- Dosya: `images/container.jpg`
- Eser: Glass food storage container with Easy Find Lids.jpg
- Yazar: Rubbermaid Products
- Kaynak: https://commons.wikimedia.org/wiki/File:Glass_food_storage_container_with_Easy_Find_Lids.jpg
- Lisans: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## scales

- Dosya: `images/scales.jpg`
- Eser: Lindells kitchen scale.jpg
- Yazar: Bengt Oberger
- Kaynak: https://commons.wikimedia.org/wiki/File:Lindells_kitchen_scale.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

