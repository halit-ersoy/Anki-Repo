# Yatak odası — 50 görselin kaynakları

Bu paketteki görseller Wikimedia Commons dosya sayfalarında belirtilen lisanslarla sunulur. Fotoğraflar ve çizimler sanatsal olarak değiştirilmemiştir; bazı dosyalar Wikimedia'nın sağladığı küçük sürümdür. Her görselin yazarı ve kendi lisansı aşağıda verilmiştir. Kaynak sayfasındaki ek atıf bilgilerini koruyun.

Uygulamanın Kaynaklar/Hakkında ekranında bu kayıtları erişilebilir tutun. JSON'daki imageAttribution alanı mevcut uygulamada kendiliğinden ekrana çıkmaz. Fotoğraflardaki marka adları uygulamanın markası değildir.

## bed

- Dosya: `images/bed.jpg`
- Eser: Cozy bedroom with a large bed and simple decor in a modern home.jpg
- Yazar: Shixart1985
- Kaynak: https://commons.wikimedia.org/wiki/File:Cozy_bedroom_with_a_large_bed_and_simple_decor_in_a_modern_home.jpg
- Lisans: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## mattress

- Dosya: `images/mattress.jpg`
- Eser: Pillowtop-mattress.jpg
- Yazar: Jeffrey M. Vinocur
- Kaynak: https://commons.wikimedia.org/wiki/File:Pillowtop-mattress.jpg
- Lisans: [CC BY 2.5](https://creativecommons.org/licenses/by/2.5)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## bed frame

- Dosya: `images/bed_frame.jpg`
- Eser: Product 965 size.jpg
- Yazar: Oliver125
- Kaynak: https://commons.wikimedia.org/wiki/File:Product_965_size.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## headboard

- Dosya: `images/headboard.jpg`
- Eser: Melamine Finish Plywood or Teakwood material headboard and footboard of cot.jpg
- Yazar: Basicstores
- Kaynak: https://commons.wikimedia.org/wiki/File:Melamine_Finish_Plywood_or_Teakwood_material_headboard_and_footboard_of_cot.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## footboard

- Dosya: `images/footboard.jpg`
- Eser: 02 pokoj1 postel.jpg
- Yazar: Ja.sem.ja
- Kaynak: https://commons.wikimedia.org/wiki/File:02_pokoj1_postel.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## pillow

- Dosya: `images/pillow.jpg`
- Eser: An average white pillow.jpg
- Yazar: 0hAerqplane
- Kaynak: https://commons.wikimedia.org/wiki/File:An_average_white_pillow.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## pillowcase

- Dosya: `images/pillowcase.jpg`
- Eser: Pillowcase MET 158824.jpg
- Yazar: This file was donated to Wikimedia Commons as part of a project by the Metropolitan Museum of Art. See the Image and Data Resources Open Access Policy
- Kaynak: https://commons.wikimedia.org/wiki/File:Pillowcase_MET_158824.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## sheet

- Dosya: `images/sheet.jpg`
- Eser: Three flat sheets.jpg
- Yazar: Stilfehler
- Kaynak: https://commons.wikimedia.org/wiki/File:Three_flat_sheets.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## fitted sheet

- Dosya: `images/fitted_sheet.jpg`
- Eser: Fitted sheet.jpg
- Yazar: The Sleep Judge
- Kaynak: https://commons.wikimedia.org/wiki/File:Fitted_sheet.jpg
- Lisans: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## duvet

- Dosya: `images/duvet.jpg`
- Eser: White-duvet.jpg
- Yazar: Wikicanadashawn
- Kaynak: https://commons.wikimedia.org/wiki/File:White-duvet.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## duvet cover

- Dosya: `images/duvet_cover.jpg`
- Eser: Crumpled duvet covered with a white cotton duvet cover 1.jpg
- Yazar: W.carter
- Kaynak: https://commons.wikimedia.org/wiki/File:Crumpled_duvet_covered_with_a_white_cotton_duvet_cover_1.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## blanket

- Dosya: `images/blanket.jpg`
- Eser: Light-blanket-3 nat.jpg
- Yazar: PureWool
- Kaynak: https://commons.wikimedia.org/wiki/File:Light-blanket-3_nat.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## bedspread

- Dosya: `images/bedspread.jpg`
- Eser: Crochet bedspread, v1.jpg
- Yazar: Garth Weals
- Kaynak: https://commons.wikimedia.org/wiki/File:Crochet_bedspread,_v1.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## quilt

- Dosya: `images/quilt.jpg`
- Eser: Green patchwork quilt sewn by hand.jpg
- Yazar: jude from new york, usa
- Kaynak: https://commons.wikimedia.org/wiki/File:Green_patchwork_quilt_sewn_by_hand.jpg
- Lisans: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## bedside table

- Dosya: `images/bedside_table.jpg`
- Eser: Aanightstand2.jpg
- Yazar: Andrewa
- Kaynak: https://commons.wikimedia.org/wiki/File:Aanightstand2.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## bedside lamp

- Dosya: `images/bedside_lamp.jpg`
- Eser: Lamp with a lampshade illuminated by sunlight.jpg
- Yazar: LoMit
- Kaynak: https://commons.wikimedia.org/wiki/File:Lamp_with_a_lampshade_illuminated_by_sunlight.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## alarm clock

- Dosya: `images/alarm_clock.jpg`
- Eser: Classic alarm clock 20180513.jpg
- Yazar: Santeri Viinamäki
- Kaynak: https://commons.wikimedia.org/wiki/File:Classic_alarm_clock_20180513.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## wardrobe

- Dosya: `images/wardrobe.jpg`
- Eser: Empty wooden wardrobe closeup.jpg
- Yazar: Shixart1985
- Kaynak: https://commons.wikimedia.org/wiki/File:Empty_wooden_wardrobe_closeup.jpg
- Lisans: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## chest of drawers

- Dosya: `images/chest_of_drawers.jpg`
- Eser: Drawer.agr.jpg
- Yazar: ArnoldReinhold
- Kaynak: https://commons.wikimedia.org/wiki/File:Drawer.agr.jpg
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## drawer

- Dosya: `images/drawer.jpg`
- Eser: Chest of drawers 1 2019-05-06.jpg
- Yazar: FASTILY
- Kaynak: https://commons.wikimedia.org/wiki/File:Chest_of_drawers_1_2019-05-06.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## dressing table

- Dosya: `images/dressing_table.jpg`
- Eser: Dressing table with chair Charles Plumet 1896.jpg
- Yazar: Yelkrokoyade
- Kaynak: https://commons.wikimedia.org/wiki/File:Dressing_table_with_chair_Charles_Plumet_1896.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## mirror

- Dosya: `images/mirror.jpg`
- Eser: Moroccan wall mirror simo.boualam issamy.jpg
- Yazar: محمد بوعلام عصامي
- Kaynak: https://commons.wikimedia.org/wiki/File:Moroccan_wall_mirror_simo.boualam_issamy.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## clothes hanger

- Dosya: `images/clothes_hanger.jpg`
- Eser: Clothes hanger.jpg
- Yazar: Yuvaldei
- Kaynak: https://commons.wikimedia.org/wiki/File:Clothes_hanger.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## clothes rail

- Dosya: `images/clothes_rail.jpg`
- Eser: Clothes rack.jpg
- Yazar: UNIFORM Studio
- Kaynak: https://commons.wikimedia.org/wiki/File:Clothes_rack.jpg
- Lisans: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## shoe rack

- Dosya: `images/shoe_rack.jpg`
- Eser: Shoe racks 2 2019-05-16.jpg
- Yazar: FASTILY
- Kaynak: https://commons.wikimedia.org/wiki/File:Shoe_racks_2_2019-05-16.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## laundry basket

- Dosya: `images/laundry_basket.jpg`
- Eser: Wasmand.jpg
- Yazar: Sietske at Dutch Wikipedia
- Kaynak: https://commons.wikimedia.org/wiki/File:Wasmand.jpg
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## storage box

- Dosya: `images/storage_box.jpg`
- Eser: Orange plastic storage container on top of a stack.jpg
- Yazar: Ser Amantio di Nicolao
- Kaynak: https://commons.wikimedia.org/wiki/File:Orange_plastic_storage_container_on_top_of_a_stack.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## suitcase

- Dosya: `images/suitcase.jpg`
- Eser: Belber Striped Suitcase.jpg
- Yazar: Sandrine Z
- Kaynak: https://commons.wikimedia.org/wiki/File:Belber_Striped_Suitcase.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## pyjamas

- Dosya: `images/pyjamas.jpg`
- Eser: Pyjamas wiki.jpg
- Yazar: Janmad
- Kaynak: https://commons.wikimedia.org/wiki/File:Pyjamas_wiki.jpg
- Lisans: [CC BY-SA 2.5](https://creativecommons.org/licenses/by-sa/2.5)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## dressing gown

- Dosya: `images/dressing_gown.jpg`
- Eser: Bademantel.JPG
- Yazar: Peng
- Kaynak: https://commons.wikimedia.org/wiki/File:Bademantel.JPG
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## slippers

- Dosya: `images/slippers.jpg`
- Eser: 2023 Kapcie.jpg
- Yazar: Jacek Halicki
- Kaynak: https://commons.wikimedia.org/wiki/File:2023_Kapcie.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## sleep mask

- Dosya: `images/sleep_mask.jpg`
- Eser: Sleep mask.jpg
- Yazar: Hbcloud at  Wikipedia
- Kaynak: https://commons.wikimedia.org/wiki/File:Sleep_mask.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## earplugs

- Dosya: `images/earplugs.jpg`
- Eser: A pair of orange foam earplugs.jpg
- Yazar: Sokolikmawwer0
- Kaynak: https://commons.wikimedia.org/wiki/File:A_pair_of_orange_foam_earplugs.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## hot-water bottle

- Dosya: `images/hot_water_bottle.jpg`
- Eser: Hot Water Bottle.jpg
- Yazar: See source file page
- Kaynak: https://commons.wikimedia.org/wiki/File:Hot_Water_Bottle.jpg
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## electric blanket

- Dosya: `images/electric_blanket.jpg`
- Eser: Electricblanket.jpg
- Yazar: Limetolime at English Wikipedia
- Kaynak: https://commons.wikimedia.org/wiki/File:Electricblanket.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## cushion

- Dosya: `images/cushion.jpg`
- Eser: Cushion.jpg
- Yazar: See source file page
- Kaynak: https://commons.wikimedia.org/wiki/File:Cushion.jpg
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## curtain

- Dosya: `images/curtain.jpg`
- Eser: Motel Window Curtains (Unsplash).jpg
- Yazar: Adi Goldstein adigold1
- Kaynak: https://commons.wikimedia.org/wiki/File:Motel_Window_Curtains_(Unsplash).jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## blind

- Dosya: `images/blind.jpg`
- Eser: Some window blinds.JPG
- Yazar: Chuck Marean
- Kaynak: https://commons.wikimedia.org/wiki/File:Some_window_blinds.JPG
- Lisans: [CC BY 3.0 us](https://creativecommons.org/licenses/by/3.0/us/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## rug

- Dosya: `images/rug.jpg`
- Eser: -Rug-.jpg
- Yazar: StefaniaRomanovv
- Kaynak: https://commons.wikimedia.org/wiki/File:-Rug-.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## carpet

- Dosya: `images/carpet.jpg`
- Eser: Teppichboden.JPG
- Yazar: Michael Fleischhacker
- Kaynak: https://commons.wikimedia.org/wiki/File:Teppichboden.JPG
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## fan

- Dosya: `images/fan.jpg`
- Eser: Electric Fan 240x355.jpg
- Yazar: Rfc1394(talk)
- Kaynak: https://commons.wikimedia.org/wiki/File:Electric_Fan_240x355.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## radiator

- Dosya: `images/radiator.jpg`
- Eser: Radiator with thermostat and heat cost allocator.jpg
- Yazar: FrankenBeer
- Kaynak: https://commons.wikimedia.org/wiki/File:Radiator_with_thermostat_and_heat_cost_allocator.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## air conditioner

- Dosya: `images/air_conditioner.jpg`
- Eser: Wall mount air conditioner.jpg
- Yazar: Kskhh
- Kaynak: https://commons.wikimedia.org/wiki/File:Wall_mount_air_conditioner.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## door

- Dosya: `images/door.jpg`
- Eser: Interior door 19-10-12 056.jpg
- Yazar: Chris Light
- Kaynak: https://commons.wikimedia.org/wiki/File:Interior_door_19-10-12_056.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## window

- Dosya: `images/window.jpg`
- Eser: Window.jpg
- Yazar: See source file page
- Kaynak: https://commons.wikimedia.org/wiki/File:Window.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## light switch

- Dosya: `images/light_switch.jpg`
- Eser: White light switch.jpg
- Yazar: Santeri Viinamäki
- Kaynak: https://commons.wikimedia.org/wiki/File:White_light_switch.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## socket

- Dosya: `images/socket.jpg`
- Eser: Mains.plug+sockets.JPG
- Yazar: Julo
- Kaynak: https://commons.wikimedia.org/wiki/File:Mains.plug%2Bsockets.JPG
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## ceiling light

- Dosya: `images/ceiling_light.jpg`
- Eser: White Ceiling Light.jpg
- Yazar: Cooldudeseven7
- Kaynak: https://commons.wikimedia.org/wiki/File:White_Ceiling_Light.jpg
- Lisans: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## shelf

- Dosya: `images/shelf.jpg`
- Eser: Carl Keksi, Wall Shelf, c. 1937, NGA 17803.jpg
- Yazar: Carl Keksi
- Kaynak: https://commons.wikimedia.org/wiki/File:Carl_Keksi,_Wall_Shelf,_c._1937,_NGA_17803.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## water bottle

- Dosya: `images/water_bottle.jpg`
- Eser: Glass Water Bottle.JPG
- Yazar: Amraepowell
- Kaynak: https://commons.wikimedia.org/wiki/File:Glass_Water_Bottle.JPG
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

