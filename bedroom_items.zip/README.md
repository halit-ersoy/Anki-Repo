# Yatak Odası — 50 İngilizce Kelime

Bu ZIP, 50 kart ve 50 görsel içerir. Her kartta İngiliz İngilizcesi IPA okunuşu, Türkçe anlam, olumlu/olumsuz/soru örneği ve her örneğin Türkçe çevirisi vardır. Toplam 150 örnek cümle ve 150 Türkçe örnek çevirisi bulunur.

## GitHub'a yükleme

`bedroom_items.zip` dosyasını açmadan `halit-ersoy/Anki-Repo` deposunun `main` dalında kök dizine yükleyin. Güncel `index.json` dosyasını aynı konumdaki eski dosyayla değiştirin. Önceki `top_100_english.zip`, `kitchen_items.zip` ve `living_room_items.zip` dosyaları korunur.

Beklenen düzen:

```text
Anki-Repo/
  index.json
  top_100_english.zip
  kitchen_items.zip
  living_room_items.zip
  bedroom_items.zip
```

Katalog: https://raw.githubusercontent.com/halit-ersoy/Anki-Repo/main/index.json
Bu paket: https://raw.githubusercontent.com/halit-ersoy/Anki-Repo/main/bedroom_items.zip

## ZIP içeriği

ZIP kökünde deck.json, images/ klasöründe 50 görsel, ayrıca README.md ve IMAGE_CREDITS.md vardır. imageUrl değerleri `images/sofa.jpg` gibi göreceli yollardır. Görsellerin yüklenmesi için internet bağlantısı gerekmez. Ses dosyası yoktur; sesli okuma cihazın konuşma motoruna bağlıdır. Yazar ve lisans bağlantıları bilgilendirme amaçlıdır; kart görselleri dış sitelerden yüklenmez.

Görsellerde farklı modeller ve kullanım örnekleri gösterilebilir. Bazı fotoğraflar çevredeki başka eşyaları da içerir. Ortak ev eşyalarının daha önceki destelerde kullanılan görselleri kaynak atıflarıyla birlikte yeniden kullanılabilir. Görsellerin atıflarını uygulamanın Kaynaklar ekranında erişilebilir tutun.

## Biçim ve içerik

Mevcut Android modeli için deckId/colorHex/word/translation/examples alanları korunmuştur. Paylaşılan yeni örnekle uyumluluk için id/accentColor/front/back/meaning/example/exampleTranslation alanları da vardır. example olumlu örneği, meaning Türkçe karşılığı tekrarlar. Kart kimlikleri `deck_bedroom_items_...` ile başlar ve diğer destelerle çakışmaz.

Duvet nevresim içine geçirilen dolgulu yorganı, duvet cover nevresimi, blanket battaniyeyi, bedspread dekoratif yatak örtüsünü, quilt ise katları dikişle birleştirilmiş kapitone örtüyü anlatır. Pillow baş yastığı, cushion dekoratif yastıktır. Fitted sheet lastikli çarşaftır. Dressing gown sabahlık anlamındadır; görsel benzer bir bornoz tipi ev giysisini gösterebilir. Pyjamas, slippers ve earplugs çoğul yapıyla kullanılır. İngiliz İngilizcesi yazımları kullanılır.

## Kontroller

ZIP bütünlüğü, 50 benzersiz kart kimliği, 50 görsel dosyası, göreceli yol eşleşmeleri ve örnek cümle alanları doğrulanmıştır. Görsel önizlemeleri incelenmiştir. Android uygulamasında uçtan uca test veya GitHub'a yükleme yapılmamıştır. Yeni paket URL'si dosya yüklenene kadar açılmaz.
