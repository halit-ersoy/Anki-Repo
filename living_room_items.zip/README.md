# Oturma Odası — 50 İngilizce Kelime

Bu ZIP, 50 kart ve 50 görsel içerir. Her kartta İngiliz İngilizcesi IPA okunuşu, Türkçe anlam, olumlu/olumsuz/soru örneği ve her örneğin Türkçe çevirisi vardır. Toplam 150 örnek cümle ve 150 Türkçe örnek çevirisi bulunur.

## GitHub'a yükleme

`living_room_items.zip` dosyasını açmadan `halit-ersoy/Anki-Repo` deposunun `main` dalında kök dizine yükleyin. Güncel `index.json` dosyasını aynı konumdaki eski dosyayla değiştirin. Önceki `top_100_english.zip` ve `kitchen_items.zip` dosyaları korunur.

Beklenen düzen:

```text
Anki-Repo/
  index.json
  top_100_english.zip
  kitchen_items.zip
  living_room_items.zip
```

Katalog: https://raw.githubusercontent.com/halit-ersoy/Anki-Repo/main/index.json
Bu paket: https://raw.githubusercontent.com/halit-ersoy/Anki-Repo/main/living_room_items.zip

## ZIP içeriği

ZIP kökünde deck.json, images/ klasöründe 50 görsel, ayrıca README.md ve IMAGE_CREDITS.md vardır. imageUrl değerleri `images/sofa.jpg` gibi göreceli yollardır. Görsellerin yüklenmesi için internet bağlantısı gerekmez. Ses dosyası yoktur; sesli okuma cihazın konuşma motoruna bağlıdır. Yazar ve lisans bağlantıları bilgilendirme amaçlıdır; kart görselleri dış sitelerden yüklenmez.

Görsellerde farklı modeller ve kullanım örnekleri gösterilebilir. Mobilya fotoğraflarının bazıları çevredeki başka eşyaları da içerir. Görsellerin atıflarını uygulamanın Kaynaklar ekranında erişilebilir tutun.

## Biçim ve içerik

Mevcut Android modeli için deckId/colorHex/word/translation/examples alanları korunmuştur. Paylaşılan yeni örnekle uyumluluk için id/accentColor/front/back/meaning/example/exampleTranslation alanları da vardır. example olumlu örneği, meaning Türkçe karşılığı tekrarlar. Kart kimlikleri `deck_living_room_items_...` ile başlar ve diğer destelerle çakışmaz.

Rug zeminin bir bölümünü kaplayan halı/kilim, carpet ise özellikle duvardan duvara halı için kullanılır. Curtain kumaş perdeyi, blind jaluzi veya stor perdeyi anlatır. Throw bu destede isim olarak koltuk şalıdır; speaker hoparlör, socket elektrik prizi, tray servis tepsisi anlamındadır. Headphones çoğul yapıyla kullanılır.

## Kontroller

ZIP bütünlüğü, 50 benzersiz kart kimliği, 50 görsel dosyası, göreceli yol eşleşmeleri ve örnek cümle alanları doğrulanmıştır. Görsel önizlemeleri incelenmiştir. Android uygulamasında uçtan uca test veya GitHub'a yükleme yapılmamıştır. Yeni paket URL'si dosya yüklenene kadar açılmaz.
