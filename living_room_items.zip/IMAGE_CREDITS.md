# Oturma odası — 50 görselin kaynakları

Bu paketteki görseller Wikimedia Commons dosya sayfalarında belirtilen lisanslarla sunulur. Fotoğraflar ve çizimler sanatsal olarak değiştirilmemiştir; bazı dosyalar Wikimedia'nın sağladığı küçük sürümdür. Her görselin yazarı ve kendi lisansı aşağıda verilmiştir. Kaynak sayfasındaki ek atıf bilgilerini koruyun.

Uygulamanın Kaynaklar/Hakkında ekranında bu kayıtları erişilebilir tutun. JSON'daki imageAttribution alanı mevcut uygulamada kendiliğinden ekrana çıkmaz. Fotoğraflardaki marka adları uygulamanın markası değildir.

## sofa

- Dosya: `images/sofa.jpg`
- Eser: Sofá 2.jpg
- Yazar: Dalton Scavassa
- Kaynak: https://commons.wikimedia.org/wiki/File:Sof%C3%A1_2.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## armchair

- Dosya: `images/armchair.jpg`
- Eser: Armchair by Machú Harras 01.jpg
- Yazar: Daniel Capilla
- Kaynak: https://commons.wikimedia.org/wiki/File:Armchair_by_Mach%C3%BA_Harras_01.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## coffee table

- Dosya: `images/coffee_table.jpg`
- Eser: Glass Coffee Table 1 2016-05-21.jpg
- Yazar: FASTILY
- Kaynak: https://commons.wikimedia.org/wiki/File:Glass_Coffee_Table_1_2016-05-21.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## side table

- Dosya: `images/side_table.png`
- Eser: Back side table pine top with mango wood legs side.png
- Yazar: Kurtkaiser
- Kaynak: https://commons.wikimedia.org/wiki/File:Back_side_table_pine_top_with_mango_wood_legs_side.png
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## bookcase

- Dosya: `images/bookcase.jpg`
- Eser: Bookcase.jpg
- Yazar: SimonP
- Kaynak: https://commons.wikimedia.org/wiki/File:Bookcase.jpg
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## TV stand

- Dosya: `images/tv_stand.jpg`
- Eser: TV stand.jpg
- Yazar: Fahat778899
- Kaynak: https://commons.wikimedia.org/wiki/File:TV_stand.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## cabinet

- Dosya: `images/cabinet.jpg`
- Eser: Cupboard.jpg
- Yazar: Deavmi
- Kaynak: https://commons.wikimedia.org/wiki/File:Cupboard.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## television

- Dosya: `images/television.jpg`
- Eser: Techwood flat screen television from 2010.jpg
- Yazar: Percivalor
- Kaynak: https://commons.wikimedia.org/wiki/File:Techwood_flat_screen_television_from_2010.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## remote control

- Dosya: `images/remote_control.jpg`
- Eser: Television remote control - black 01.jpg
- Yazar: Dmitry Makeev
- Kaynak: https://commons.wikimedia.org/wiki/File:Television_remote_control_-_black_01.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## speaker

- Dosya: `images/speaker.jpg`
- Eser: Bass reflex loudspeakers by Focal-JMLab.jpg
- Yazar: The original description page was here. All following user names refer to he.wikipedia.
- Kaynak: https://commons.wikimedia.org/wiki/File:Bass_reflex_loudspeakers_by_Focal-JMLab.jpg
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## floor lamp

- Dosya: `images/floor_lamp.jpg`
- Eser: Floor lamp 1 2016-07-06.jpg
- Yazar: FASTILY
- Kaynak: https://commons.wikimedia.org/wiki/File:Floor_lamp_1_2016-07-06.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## table lamp

- Dosya: `images/table_lamp.jpg`
- Eser: Lamp with a lampshade illuminated by sunlight.jpg
- Yazar: LoMit
- Kaynak: https://commons.wikimedia.org/wiki/File:Lamp_with_a_lampshade_illuminated_by_sunlight.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## ceiling light

- Dosya: `images/ceiling_light.jpg`
- Eser: White Ceiling Light.jpg
- Yazar: Cooldudeseven7
- Kaynak: https://commons.wikimedia.org/wiki/File:White_Ceiling_Light.jpg
- Lisans: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## rug

- Dosya: `images/rug.jpg`
- Eser: -Rug-.jpg
- Yazar: StefaniaRomanovv
- Kaynak: https://commons.wikimedia.org/wiki/File:-Rug-.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## carpet

- Dosya: `images/carpet.jpg`
- Eser: Teppichboden.JPG
- Yazar: Michael Fleischhacker
- Kaynak: https://commons.wikimedia.org/wiki/File:Teppichboden.JPG
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## curtain

- Dosya: `images/curtain.jpg`
- Eser: Motel Window Curtains (Unsplash).jpg
- Yazar: Adi Goldstein adigold1
- Kaynak: https://commons.wikimedia.org/wiki/File:Motel_Window_Curtains_(Unsplash).jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## blind

- Dosya: `images/blind.jpg`
- Eser: Some window blinds.JPG
- Yazar: Chuck Marean
- Kaynak: https://commons.wikimedia.org/wiki/File:Some_window_blinds.JPG
- Lisans: [CC BY 3.0 us](https://creativecommons.org/licenses/by/3.0/us/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## cushion

- Dosya: `images/cushion.jpg`
- Eser: Cushion.jpg
- Yazar: See source file page
- Kaynak: https://commons.wikimedia.org/wiki/File:Cushion.jpg
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## throw

- Dosya: `images/throw.jpg`
- Eser: Blue, pink, white, purple crochet blanket 1.jpg
- Yazar: 999real
- Kaynak: https://commons.wikimedia.org/wiki/File:Blue,_pink,_white,_purple_crochet_blanket_1.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## clock

- Dosya: `images/clock.jpg`
- Eser: Wall clock quartz.jpg
- Yazar: Sridhar Rao
- Kaynak: https://commons.wikimedia.org/wiki/File:Wall_clock_quartz.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## mirror

- Dosya: `images/mirror.jpg`
- Eser: Moroccan wall mirror simo.boualam issamy.jpg
- Yazar: محمد بوعلام عصامي
- Kaynak: https://commons.wikimedia.org/wiki/File:Moroccan_wall_mirror_simo.boualam_issamy.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## picture frame

- Dosya: `images/picture_frame.jpg`
- Eser: Empty Picture Frame on the Wall (51920214882).jpg
- Yazar: Dejan Krsmanovic
- Kaynak: https://commons.wikimedia.org/wiki/File:Empty_Picture_Frame_on_the_Wall_(51920214882).jpg
- Lisans: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## painting

- Dosya: `images/painting.jpg`
- Eser: Oeuvre pour salon by Basile Morin, 2003 - framed abstract acrylic painting with blue rectangles on a wall.jpg
- Yazar: Basile Morin
- Kaynak: https://commons.wikimedia.org/wiki/File:Oeuvre_pour_salon_by_Basile_Morin,_2003_-_framed_abstract_acrylic_painting_with_blue_rectangles_on_a_wall.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## vase

- Dosya: `images/vase.jpg`
- Eser: Chinese vase.jpg
- Yazar: André Karwath aka Aka
- Kaynak: https://commons.wikimedia.org/wiki/File:Chinese_vase.jpg
- Lisans: [CC BY-SA 2.5](https://creativecommons.org/licenses/by-sa/2.5)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## houseplant

- Dosya: `images/houseplant.jpg`
- Eser: Houseplant Calathea orbifolia.jpg
- Yazar: Supsoph
- Kaynak: https://commons.wikimedia.org/wiki/File:Houseplant_Calathea_orbifolia.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## flowerpot

- Dosya: `images/flowerpot.jpg`
- Eser: 3D printed flower pots.jpg
- Yazar: Aaaatu
- Kaynak: https://commons.wikimedia.org/wiki/File:3D_printed_flower_pots.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## fireplace

- Dosya: `images/fireplace.jpg`
- Eser: Fireplace-RM.jpg
- Yazar: Ryan Mahle from Sherman Oaks, CA, USA
- Kaynak: https://commons.wikimedia.org/wiki/File:Fireplace-RM.jpg
- Lisans: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## candle

- Dosya: `images/candle.jpg`
- Eser: Red candle flame.jpg
- Yazar: BogTar201213
- Kaynak: https://commons.wikimedia.org/wiki/File:Red_candle_flame.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## candle holder

- Dosya: `images/candle_holder.jpg`
- Eser: Crystal candle holder (49741063413).jpg
- Yazar: Frans Berkelaar
- Kaynak: https://commons.wikimedia.org/wiki/File:Crystal_candle_holder_(49741063413).jpg
- Lisans: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## fan

- Dosya: `images/fan.jpg`
- Eser: Electric Fan 240x355.jpg
- Yazar: Rfc1394(talk)
- Kaynak: https://commons.wikimedia.org/wiki/File:Electric_Fan_240x355.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## radiator

- Dosya: `images/radiator.jpg`
- Eser: Radiator with thermostat and heat cost allocator.jpg
- Yazar: FrankenBeer
- Kaynak: https://commons.wikimedia.org/wiki/File:Radiator_with_thermostat_and_heat_cost_allocator.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## air conditioner

- Dosya: `images/air_conditioner.jpg`
- Eser: Wall mount air conditioner.jpg
- Yazar: Kskhh
- Kaynak: https://commons.wikimedia.org/wiki/File:Wall_mount_air_conditioner.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## coaster

- Dosya: `images/coaster.jpg`
- Eser: Cork coaster.jpg
- Yazar: André Karwath aka Aka
- Kaynak: https://commons.wikimedia.org/wiki/File:Cork_coaster.jpg
- Lisans: [CC BY-SA 2.5](https://creativecommons.org/licenses/by-sa/2.5)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## tray

- Dosya: `images/tray.jpg`
- Eser: Serving Tray - Maple & Other Rare Woods.jpg
- Yazar: Smsilverman342
- Kaynak: https://commons.wikimedia.org/wiki/File:Serving_Tray_-_Maple_%26_Other_Rare_Woods.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## newspaper

- Dosya: `images/newspaper.jpg`
- Eser: Newspaper.jpg
- Yazar: Unknown authorUnknown author
- Kaynak: https://commons.wikimedia.org/wiki/File:Newspaper.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## magazine

- Dosya: `images/magazine.jpg`
- Eser: Kazoo Magazine, Issue 24.jpg
- Yazar: BJCHK
- Kaynak: https://commons.wikimedia.org/wiki/File:Kazoo_Magazine,_Issue_24.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## book

- Dosya: `images/book.jpg`
- Eser: Book.jpg
- Yazar: See source file page
- Kaynak: https://commons.wikimedia.org/wiki/File:Ezra_Cornell%27s_first_book.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## games console

- Dosya: `images/games_console.png`
- Eser: Four gaming consoles (cropped).png
- Yazar: Oskar Carrieri, Adam Ginalski
- Kaynak: https://commons.wikimedia.org/wiki/File:Four_gaming_consoles_(cropped).png
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## board game

- Dosya: `images/board_game.jpg`
- Eser: Castles of Burgundy (Board Game).jpg
- Yazar: Mshuang2
- Kaynak: https://commons.wikimedia.org/wiki/File:Castles_of_Burgundy_(Board_Game).jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## chessboard

- Dosya: `images/chessboard.jpg`
- Eser: Empty wooden chessboard.jpg
- Yazar: Paul Lloyd
- Kaynak: https://commons.wikimedia.org/wiki/File:Empty_wooden_chessboard.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## storage basket

- Dosya: `images/storage_basket.jpg`
- Eser: 02024 1966 Vintage wicker basket for pottery.jpg
- Yazar: Silar
- Kaynak: https://commons.wikimedia.org/wiki/File:02024_1966_Vintage_wicker_basket_for_pottery.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## laptop

- Dosya: `images/laptop.jpg`
- Eser: IBM Thinkpad R51.jpg
- Yazar: André Karwath aka Aka
- Kaynak: https://commons.wikimedia.org/wiki/File:IBM_Thinkpad_R51.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## headphones

- Dosya: `images/headphones.jpg`
- Eser: Headphones on white background.jpg
- Yazar: Sprinno
- Kaynak: https://commons.wikimedia.org/wiki/File:Headphones_on_white_background.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## socket

- Dosya: `images/socket.jpg`
- Eser: Mains.plug+sockets.JPG
- Yazar: Julo
- Kaynak: https://commons.wikimedia.org/wiki/File:Mains.plug%2Bsockets.JPG
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## extension lead

- Dosya: `images/extension_lead.jpg`
- Eser: Power strip for Euro plug and schuko.jpg
- Yazar: Jarlhelm
- Kaynak: https://commons.wikimedia.org/wiki/File:Power_strip_for_Euro_plug_and_schuko.jpg
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## light switch

- Dosya: `images/light_switch.jpg`
- Eser: White light switch.jpg
- Yazar: Santeri Viinamäki
- Kaynak: https://commons.wikimedia.org/wiki/File:White_light_switch.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## door

- Dosya: `images/door.jpg`
- Eser: Interior door 19-10-12 056.jpg
- Yazar: Chris Light
- Kaynak: https://commons.wikimedia.org/wiki/File:Interior_door_19-10-12_056.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## window

- Dosya: `images/window.jpg`
- Eser: Window.jpg
- Yazar: See source file page
- Kaynak: https://commons.wikimedia.org/wiki/File:Window.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## shelf

- Dosya: `images/shelf.jpg`
- Eser: Carl Keksi, Wall Shelf, c. 1937, NGA 17803.jpg
- Yazar: Carl Keksi
- Kaynak: https://commons.wikimedia.org/wiki/File:Carl_Keksi,_Wall_Shelf,_c._1937,_NGA_17803.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## footstool

- Dosya: `images/footstool.jpg`
- Eser: Puff Redondo Baixo 2.jpg
- Yazar: Rodrigomariadafe
- Kaynak: https://commons.wikimedia.org/wiki/File:Puff_Redondo_Baixo_2.jpg
- Lisans: [CC BY 3.0](https://creativecommons.org/licenses/by/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

