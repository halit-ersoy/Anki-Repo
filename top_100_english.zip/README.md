# En Sık Kullanılan 100 İngilizce Kelime — çevrimdışı paket

Bu ZIP'in kökünde deck.json ve images/ klasörü bulunur. Kartların imageUrl alanları ZIP içindeki dosyalara görecelidir. Bu alanlara file:/// yazılmaz; uygulama çıkardıktan sonra cihazdaki yerel yolu oluşturur.

Kart sayısı: 100
Görselli kart sayısı: 25
Görselsiz kart sayısı: 75
İçerik sürümü: 2

Mevcut Android uygulamasının okuduğu deckId, colorHex, word, translation ve examples alanları korunmuştur. Paylaşılan yeni örnekteki id, accentColor, front, back, meaning, example ve exampleTranslation alanları aynı içeriğin uyum alanlarıdır. examples içinde olumlu, olumsuz ve soru örnekleri eksiksizdir. example alanı olumlu örneğin kopyasıdır. meaning alanı mevcut Türkçe karşılığın kopyasıdır; ayrı bir sözlük tanımı eklenmemiştir.

Bu paket yerel uygulama kodundaki ZIP okuyucusuna göre hazırlanmıştır; Android üzerinde yükleme/çalıştırma testi yapılmamıştır. Tam çevrimdışı kart metni ve mevcut görseller paket içindedir. Ses kaydı içermez; sesli okumanın çevrimdışı çalışması cihazın konuşma motoruna bağlıdır. Kaynak/lisans bağlantıları bilgilendirme içindir; kart görsellerini yüklemek için kullanılmaz.

Öğrenme ilerlemesiyle ilgili not: incelenen ZIP aktarım kodu aynı deste kimliğinde eski kartları kaldırıp yeniden ekliyor. Bu paket kimlikleri korur, fakat mevcut uygulamada yeniden içe aktarma ilerlemeyi sıfırlayabilir.

Sıklık listesindeki 75 kartın önceki gibi görseli yoktur. The/of/and gibi dilbilgisi kelimeleri açıklama ve örneklerle çalışılır. Mevcut 25 görselin tamamı pakete eklenmiştir.
