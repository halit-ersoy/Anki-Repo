# Görsel kaynakları

İlk 100 kelime destesindeki 25 PNG görsel, **OpenMoji contributors** tarafından oluşturulmuştur.

- Proje: https://openmoji.org/
- Kaynak depo: https://github.com/hfg-gmuend/openmoji
- Lisans: Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
- Lisans bağlantısı: https://creativecommons.org/licenses/by-sa/4.0/
- Kaynak sürüm: `aeb8bb3a59e2de39c754ac79180c8131c906acea`
- İndirme tarihi: 2026-10-21
- Değişiklik: Yok. Kaynak PNG dosyaları yalnızca kelime adına göre yeniden adlandırılmıştır.
- Lisansın kopyası: `licenses/OpenMoji-LICENSE.txt`

Görseller fotoğraf değildir; kelimeye ilişkin bir çağrışımı gösteren çizimlerdir. Örneğin "make" için küçük bir kek, "give" için hediye, "know" için ampul kullanılmıştır. Birden fazla anlamı olan kelimenin bütün kullanımlarını açıklamazlar. "go" ve "come" için aynı yürüme çizimi kullanılmıştır; yön farkı örnek cümlelerle öğretilir.

Uygulamanın Hakkında/Kaynaklar ekranına şu atfı ve bağlantıları ekleyin:

> Illustrations by OpenMoji contributors — https://openmoji.org/ — licensed under CC BY-SA 4.0 — https://creativecommons.org/licenses/by-sa/4.0/. Original artwork, unmodified.

JSON içindeki `imageAttribution` alanı atıf bilgisini taşır; mevcut uygulama bu alanı ekranda kendiliğinden göstermez.

| Kelime | Paket içindeki dosya | Özgün kaynak |
|---|---|---|
| say | `images/say.png` | [OpenMoji 1F4AC](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F4AC.png) |
| one | `images/one.png` | [OpenMoji 0031-FE0F-20E3](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/0031-FE0F-20E3.png) |
| up | `images/up.png` | [OpenMoji 2B06](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/2B06.png) |
| out | `images/out.png` | [OpenMoji 1F6AA](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F6AA.png) |
| go | `images/go.png` | [OpenMoji 1F6B6](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F6B6.png) |
| make | `images/make.png` | [OpenMoji 1F9C1](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F9C1.png) |
| like | `images/like.png` | [OpenMoji 2764](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/2764.png) |
| time | `images/time.png` | [OpenMoji 23F0](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/23F0.png) |
| know | `images/know.png` | [OpenMoji 1F4A1](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F4A1.png) |
| people | `images/people.png` | [OpenMoji 1F465](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F465.png) |
| year | `images/year.png` | [OpenMoji 1F4C5](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F4C5.png) |
| good | `images/good.png` | [OpenMoji 1F44D](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F44D.png) |
| see | `images/see.png` | [OpenMoji 1F441](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F441.png) |
| look | `images/look.png` | [OpenMoji 1F440](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F440.png) |
| come | `images/come.png` | [OpenMoji 1F6B6](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F6B6.png) |
| think | `images/think.png` | [OpenMoji 1F4AD](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F4AD.png) |
| back | `images/back.png` | [OpenMoji 1F519](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F519.png) |
| use | `images/use.png` | [OpenMoji 1F528](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F528.png) |
| two | `images/two.png` | [OpenMoji 0032-FE0F-20E3](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/0032-FE0F-20E3.png) |
| work | `images/work.png` | [OpenMoji 1F4BC](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F4BC.png) |
| first | `images/first.png` | [OpenMoji 1F947](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F947.png) |
| way | `images/way.png` | [OpenMoji 1F6E3](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F6E3.png) |
| new | `images/new.png` | [OpenMoji 2728](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/2728.png) |
| give | `images/give.png` | [OpenMoji 1F381](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F381.png) |
| day | `images/day.png` | [OpenMoji 1F305](https://raw.githubusercontent.com/hfg-gmuend/openmoji/aeb8bb3a59e2de39c754ac79180c8131c906acea/color/618x618/1F305.png) |
