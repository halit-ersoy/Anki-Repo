# Banyo ve kişisel bakım — 50 görselin kaynakları

Bu paketteki 49 görsel Wikimedia Commons dosya sayfalarında belirtilen lisanslarla sunulur. Tuvalet kâğıtlığı görseli bu deste için yapay zekâyla oluşturulmuştur; onun yöntem ve istemi GENERATED_IMAGES.md dosyasındadır. Fotoğraflar ve çizimler sanatsal olarak değiştirilmemiştir; bazı dosyalar Wikimedia'nın sağladığı küçük sürümdür. Her görselin yazarı ve kendi lisansı aşağıda verilmiştir. Kaynak sayfasındaki ek atıf bilgilerini koruyun.

Uygulamanın Kaynaklar/Hakkında ekranında bu kayıtları erişilebilir tutun. JSON'daki imageAttribution alanı mevcut uygulamada kendiliğinden ekrana çıkmaz. Fotoğraflardaki marka adları uygulamanın markası değildir.

## toothbrush

- Dosya: `images/toothbrush.jpg`
- Eser: Toothbrush 20050716 004.jpg
- Yazar: Jonas Bergsten
- Kaynak: https://commons.wikimedia.org/wiki/File:Toothbrush_20050716_004.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## toothpaste

- Dosya: `images/toothpaste.jpg`
- Eser: Zendium toothpaste tubes.jpg
- Yazar: Thomas Angermann
- Kaynak: https://commons.wikimedia.org/wiki/File:Zendium_toothpaste_tubes.jpg
- Lisans: [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## dental floss

- Dosya: `images/dental_floss.png`
- Eser: Dental floss 2.png
- Yazar: Tiia Monto
- Kaynak: https://commons.wikimedia.org/wiki/File:Dental_floss_2.png
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## mouthwash

- Dosya: `images/mouthwash.jpg`
- Eser: Colgate Alcohol Free Mouthwash.jpg
- Yazar: Editor182 (talk)
- Kaynak: https://commons.wikimedia.org/wiki/File:Colgate_Alcohol_Free_Mouthwash.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## tongue scraper

- Dosya: `images/tongue_scraper.png`
- Eser: Tongue Scraper Ayurvedic Copper.png
- Yazar: Rioter 1
- Kaynak: https://commons.wikimedia.org/wiki/File:Tongue_Scraper_Ayurvedic_Copper.png
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## electric toothbrush

- Dosya: `images/electric_toothbrush.jpg`
- Eser: Electric toothbrush on a white background.jpg
- Yazar: Curpharar
- Kaynak: https://commons.wikimedia.org/wiki/File:Electric_toothbrush_on_a_white_background.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## toothbrush holder

- Dosya: `images/toothbrush_holder.jpg`
- Eser: Metallic Toothbrush Holder.jpg
- Yazar: Galikben
- Kaynak: https://commons.wikimedia.org/wiki/File:Metallic_Toothbrush_Holder.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## soap

- Dosya: `images/soap.jpg`
- Eser: Aleppo soap 01.jpg
- Yazar: Bernard Gagnon
- Kaynak: https://commons.wikimedia.org/wiki/File:Aleppo_soap_01.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## soap dish

- Dosya: `images/soap_dish.jpg`
- Eser: Ceramic Soap Dish.jpg
- Yazar: LeoHier51
- Kaynak: https://commons.wikimedia.org/wiki/File:Ceramic_Soap_Dish.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## liquid soap

- Dosya: `images/liquid_soap.jpg`
- Eser: Liquid hand soaps in Japan.jpg
- Yazar: Danny Choo
- Kaynak: https://commons.wikimedia.org/wiki/File:Liquid_hand_soaps_in_Japan.jpg
- Lisans: [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## soap dispenser

- Dosya: `images/soap_dispenser.jpg`
- Eser: Wall-mounted manual liquid soap dispenser with chrome finish.jpg
- Yazar: Knowledge and philosophy
- Kaynak: https://commons.wikimedia.org/wiki/File:Wall-mounted_manual_liquid_soap_dispenser_with_chrome_finish.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## shampoo

- Dosya: `images/shampoo.jpg`
- Eser: Dove shampoo bottle.jpg
- Yazar: Ranjima np
- Kaynak: https://commons.wikimedia.org/wiki/File:Dove_shampoo_bottle.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## conditioner

- Dosya: `images/conditioner.jpg`
- Eser: Conditioner - Hair treatment.jpg
- Yazar: geehairimages
- Kaynak: https://commons.wikimedia.org/wiki/File:Conditioner_-_Hair_treatment.jpg
- Lisans: [CC BY 2.0](https://creativecommons.org/licenses/by/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## shower gel

- Dosya: `images/shower_gel.jpg`
- Eser: THANN Aromatic Wood Shower Gel.jpg
- Yazar: THANN-Oryza Co., Ltd
- Kaynak: https://commons.wikimedia.org/wiki/File:THANN_Aromatic_Wood_Shower_Gel.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## body lotion

- Dosya: `images/body_lotion.jpg`
- Eser: Warm Vanilla Sugar shower gel and lotion.jpg
- Yazar: SarahMalik32
- Kaynak: https://commons.wikimedia.org/wiki/File:Warm_Vanilla_Sugar_shower_gel_and_lotion.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## sunscreen

- Dosya: `images/sunscreen.jpg`
- Eser: LRP sunscreen bottle.jpg
- Yazar: Netstars22
- Kaynak: https://commons.wikimedia.org/wiki/File:LRP_sunscreen_bottle.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## deodorant

- Dosya: `images/deodorant.jpg`
- Eser: 2023 Dezodoranty Nivea.jpg
- Yazar: Jacek Halicki
- Kaynak: https://commons.wikimedia.org/wiki/File:2023_Dezodoranty_Nivea.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## perfume

- Dosya: `images/perfume.jpg`
- Eser: Bottle of L'Aimant perfume - Coty -1927-1.jpg
- Yazar: DDupard
- Kaynak: https://commons.wikimedia.org/wiki/File:Bottle_of_L%27Aimant_perfume_-_Coty_-1927-1.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## razor

- Dosya: `images/razor.jpg`
- Eser: Safety razor shaving kit.jpg
- Yazar: Hustvedt
- Kaynak: https://commons.wikimedia.org/wiki/File:Safety_razor_shaving_kit.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## shaving foam

- Dosya: `images/shaving_foam.jpg`
- Eser: Old Pirkka shaving foam package.jpg
- Yazar: Arkke
- Kaynak: https://commons.wikimedia.org/wiki/File:Old_Pirkka_shaving_foam_package.jpg
- Lisans: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## aftershave

- Dosya: `images/aftershave.jpg`
- Eser: Tabac Original after shave bottle 50ml.jpg
- Yazar: Alex P. Kok
- Kaynak: https://commons.wikimedia.org/wiki/File:Tabac_Original_after_shave_bottle_50ml.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## comb

- Dosya: `images/comb.jpg`
- Eser: Plastic comb, 2015-06-07.jpg
- Yazar: Crisco 1492
- Kaynak: https://commons.wikimedia.org/wiki/File:Plastic_comb,_2015-06-07.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## hairbrush

- Dosya: `images/hairbrush.jpg`
- Eser: Hairbrush flat.JPG
- Yazar: en:User:Musical Linguist
- Kaynak: https://commons.wikimedia.org/wiki/File:Hairbrush_flat.JPG
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## hairdryer

- Dosya: `images/hairdryer.jpg`
- Eser: HITACHI HAIR DRYER HD-1650.jpg
- Yazar: Dinkun Chen
- Kaynak: https://commons.wikimedia.org/wiki/File:HITACHI_HAIR_DRYER_HD-1650.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## hair straightener

- Dosya: `images/hair_straightener.jpg`
- Eser: Hair straightener TTH2510 by Tescom (2015-09-19).JPG
- Yazar: Lombroso
- Kaynak: https://commons.wikimedia.org/wiki/File:Hair_straightener_TTH2510_by_Tescom_(2015-09-19).JPG
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## nail clippers

- Dosya: `images/nail_clippers.jpg`
- Eser: Nail clippers silver.JPG
- Yazar: BarberJP
- Kaynak: https://commons.wikimedia.org/wiki/File:Nail_clippers_silver.JPG
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## nail file

- Dosya: `images/nail_file.jpg`
- Eser: Glass nail file green.jpg
- Yazar: Fanny Schertzer
- Kaynak: https://commons.wikimedia.org/wiki/File:Glass_nail_file_green.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## tweezers

- Dosya: `images/tweezers.jpg`
- Eser: Small tweezers-set 1.jpg
- Yazar: real name: Nadina Wiórkiewicz
pl.wiki: Nadine90
commons: Nadine90
- Kaynak: https://commons.wikimedia.org/wiki/File:Small_tweezers-set_1.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## cotton bud

- Dosya: `images/cotton_bud.jpg`
- Eser: A white cotton swab!.jpg
- Yazar: Suntuniustin
- Kaynak: https://commons.wikimedia.org/wiki/File:A_white_cotton_swab!.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## cotton pad

- Dosya: `images/cotton_pad.jpg`
- Eser: Cotton pads - Δίσκοι ντεμακιγιάζ.JPG
- Yazar: Evi Michailidou
- Kaynak: https://commons.wikimedia.org/wiki/File:Cotton_pads_-_%CE%94%CE%AF%CF%83%CE%BA%CE%BF%CE%B9_%CE%BD%CF%84%CE%B5%CE%BC%CE%B1%CE%BA%CE%B9%CE%B3%CE%B9%CE%AC%CE%B6.JPG
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## tissue

- Dosya: `images/tissue.jpg`
- Eser: A tissue box.jpg
- Yazar: Captain MarcusL
- Kaynak: https://commons.wikimedia.org/wiki/File:A_tissue_box.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## toilet paper

- Dosya: `images/toilet_paper.jpg`
- Eser: Roll of toilet paper with one sheet folded down in front.jpg
- Yazar: Derrick Coetzee (User:Dcoetzee)
- Kaynak: https://commons.wikimedia.org/wiki/File:Roll_of_toilet_paper_with_one_sheet_folded_down_in_front.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## towel

- Dosya: `images/towel.jpg`
- Eser: Towel and small towel.jpg
- Yazar: Jessica F.
- Kaynak: https://commons.wikimedia.org/wiki/File:Towel_and_small_towel.jpg
- Lisans: [CC BY 2.5](https://creativecommons.org/licenses/by/2.5)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## hand towel

- Dosya: `images/hand_towel.jpg`
- Eser: Four Seasons Westlake Village Hand Towels 2014.jpg
- Yazar: Patrick Pelletier
- Kaynak: https://commons.wikimedia.org/wiki/File:Four_Seasons_Westlake_Village_Hand_Towels_2014.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## bath towel

- Dosya: `images/bath_towel.jpg`
- Eser: Zusammengelegte Handtücher.jpg
- Yazar: User:Mattes
- Kaynak: https://commons.wikimedia.org/wiki/File:Zusammengelegte_Handt%C3%BCcher.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## bathrobe

- Dosya: `images/bathrobe.jpg`
- Eser: Bademantel.JPG
- Yazar: Peng
- Kaynak: https://commons.wikimedia.org/wiki/File:Bademantel.JPG
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## bath mat

- Dosya: `images/bath_mat.jpg`
- Eser: Bathroom Rug by Chelsea Morgan.jpg
- Yazar: Chelsea Morgan
- Kaynak: https://commons.wikimedia.org/wiki/File:Bathroom_Rug_by_Chelsea_Morgan.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## toilet

- Dosya: `images/toilet.jpg`
- Eser: Flush toilet.jpg
- Yazar: Kantikkantemirgonov
- Kaynak: https://commons.wikimedia.org/wiki/File:Flush_toilet.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## toilet brush

- Dosya: `images/toilet_brush.jpg`
- Eser: Klobuersten (fcm).jpg
- Yazar: Photograph:  Frank C. Müller, Baden-Baden
- Kaynak: https://commons.wikimedia.org/wiki/File:Klobuersten_(fcm).jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## toilet seat

- Dosya: `images/toilet_seat.jpg`
- Eser: Decorative toilet seat.jpg
- Yazar: No machine-readable author provided. Bartux~commonswiki assumed (based on copyright claims).
- Kaynak: https://commons.wikimedia.org/wiki/File:Decorative_toilet_seat.jpg
- Lisans: [Public domain](https://commons.wikimedia.org/wiki/Commons:Public_domain)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## toilet roll holder

- Dosya: `images/toilet_roll_holder.png`
- Bu görsel bu deste için yerleşik görsel oluşturma aracıyla üretildi; üçüncü taraf fotoğraf kaynağı yoktur.
- Tam istem ve yöntem: GENERATED_IMAGES.md

## shower

- Dosya: `images/shower.jpg`
- Eser: GD 廣東 Guangdong 廣州 Guangzhou Huangpu MUSTEL Hotel Knowledge City 浴室 bathroom shower June 2025 R12S 04.jpg
- Yazar: MeiOLA 2290 WMENSZ
- Kaynak: https://commons.wikimedia.org/wiki/File:GD_%E5%BB%A3%E6%9D%B1_Guangdong_%E5%BB%A3%E5%B7%9E_Guangzhou_Huangpu_MUSTEL_Hotel_Knowledge_City_%E6%B5%B4%E5%AE%A4_bathroom_shower_June_2025_R12S_04.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## shower head

- Dosya: `images/shower_head.jpg`
- Eser: Shower head.JPG
- Yazar: Nicole-Koehler
- Kaynak: https://commons.wikimedia.org/wiki/File:Shower_head.JPG
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## shower curtain

- Dosya: `images/shower_curtain.jpg`
- Eser: A shower curtain in Hotel Milano (Marina di Pietrasanta).jpg
- Yazar: János Korom Dr.  >17 Million views from Wien, Austria
- Kaynak: https://commons.wikimedia.org/wiki/File:A_shower_curtain_in_Hotel_Milano_(Marina_di_Pietrasanta).jpg
- Lisans: [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## bathtub

- Dosya: `images/bathtub.jpg`
- Eser: Bathtub of Khan Pool Suite in Amantaka luxury Resort & Hotel in Luang Prabang Laos.jpg
- Yazar: Basile Morin
- Kaynak: https://commons.wikimedia.org/wiki/File:Bathtub_of_Khan_Pool_Suite_in_Amantaka_luxury_Resort_%26_Hotel_in_Luang_Prabang_Laos.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## washbasin

- Dosya: `images/washbasin.jpg`
- Eser: Wash basin gn.jpg
- Yazar: Gnangcomapp
- Kaynak: https://commons.wikimedia.org/wiki/File:Wash_basin_gn.jpg
- Lisans: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## tap

- Dosya: `images/tap.jpg`
- Eser: Kitchen Faucet 1.jpg
- Yazar: Stilfehler
- Kaynak: https://commons.wikimedia.org/wiki/File:Kitchen_Faucet_1.jpg
- Lisans: [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## mirror

- Dosya: `images/mirror.jpg`
- Eser: Moroccan wall mirror simo.boualam issamy.jpg
- Yazar: محمد بوعلام عصامي
- Kaynak: https://commons.wikimedia.org/wiki/File:Moroccan_wall_mirror_simo.boualam_issamy.jpg
- Lisans: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## laundry basket

- Dosya: `images/laundry_basket.jpg`
- Eser: Wasmand.jpg
- Yazar: Sietske at Dutch Wikipedia
- Kaynak: https://commons.wikimedia.org/wiki/File:Wasmand.jpg
- Lisans: [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

## scales

- Dosya: `images/scales.jpg`
- Eser: MyWeigh Phoenix bathroom scale (360112654).jpg
- Yazar: D.L.
- Kaynak: https://commons.wikimedia.org/wiki/File:MyWeigh_Phoenix_bathroom_scale_(360112654).jpg
- Lisans: [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0)
- Değişiklik: Sanatsal değişiklik yok; kaynak tarafından sunulan küçük sürüm kullanılmış olabilir.

